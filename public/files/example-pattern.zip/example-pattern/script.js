document.addEventListener('DOMContentLoaded', init)

function init(){
	var container = document.getElementById("container")
	var controllerOne = document.getElementById("control-1")
	var controllerTwo = document.getElementById("control-2")
	var controllerThree = document.getElementById("control-3")
	console.log("page has loaded!")

	controllerOne.addEventListener('click', controlOne)
	controllerTwo.addEventListener('click', controlTwo)
	controllerThree.addEventListener('click', controlThree)
	
	// add pattern
	for (var i = 0; i < 100; i++) {
		container.insertAdjacentHTML('beforeend', patternUnit(i))
		// add mouseover function for each element
		mouseInteraction(i)

	}
}

function patternUnit(index){
	return `<div id="unit-${index}" class="patternUnit">🐺</div>`
}

function mouseInteraction(index){
	document.getElementById("unit-" + index).addEventListener('mouseover', function(e){
		if(e.target.classList.contains("black")){
			e.target.classList.remove("black")
		}else{
			e.target.classList.add("black")
		}
	})
}

function controlOne(){

	var patternUnits = document.querySelectorAll(".patternUnit")

	patternUnits.forEach(function(unit){
		if(unit.classList.contains("rounded")){
			unit.classList.remove("rounded")
		}else{
			unit.classList.add("rounded")
		}
	})

}


function controlTwo(){

	var patternUnits = document.querySelectorAll(".patternUnit")

	patternUnits.forEach(function(unit){
		if(unit.classList.contains("rotated")){
			unit.classList.remove("rotated")
		}else{
			unit.classList.add("rotated")
		}
	})

}

function controlThree(){
	var patternUnits = document.querySelectorAll(".patternUnit")

	patternUnits.forEach(function(unit){
		
		var r = Math.round(Math.random()*255)
		var g = Math.round(Math.random()*255)
		var b = Math.round(Math.random()*255)

		unit.classList.remove("black")

		unit.style.backgroundColor = `rgb(${r}, ${g}, ${b})`


	})


}