/* BOILERPLATE JS */

/* this is a comment */
console.log("hello!");

// variables

let myString = "my string";
myString = "my other string";
const myOtherString = "something"; // cannot redefine

var myNumber = -123

var myFloat =  2 * (1.23456 - 2)
		
		myFloat =  2 * 1.23456 - 2; // redefining

		/*
			this is a comment
		*/


var myBoolean = false;

var myArray = ["items", "in", "a", "list"];

var myCoords = [22, 45];

	myArray[1] = 44

console.log(myArray)


var myObject = {
	name : "Lukas",
	lastname : ["Eigler", "Harding"]
}

console.log(myObject['lastname'][0])


// functions

function myFunction(num1){

	console.log(num1)
}

myFunction("hello again!")
myFunction("greetings!")


function adding(num1, num2){

	var addition = num1 + num2;

	return addition

}

var result = adding(3, 6);
var myNewResult = adding(result, 33)
console.log(myNewResult)


// how do we grab something from our html?

// single item

var mydiv = document.getElementById("myDiv")
var myParagraph = document.querySelector("p:last-of-type")

console.log(myParagraph)

// group of items
var myParagraphs = document.querySelectorAll("p")
var myClasses = document.querySelectorAll(".myClass")


// changing css (classes + inline)

mydiv.classList.add("anotherClass")
// mydiv.classList.remove("anotherClass")
// mydiv.classList.contains("anotherClass") // true or false


var r = Math.round(Math.random()*255) // algebra class
var g = Math.floor(Math.random()*255) // down
var b = Math.ceil(Math.random()*255) // up

myParagraph.style.backgroundColor = `rgb(${r}, ${g}, ${b})`

var font = 10 + Math.random()*15;
myParagraph.style.fontSize = `${font}px`


var classNumber = Math.ceil(Math.random()*3)

myParagraph.classList.add(`class-${classNumber}`)


// add new html content
myParagraph.innerHTML =  " new content" + classNumber + myParagraph.innerHTML;


// adding new elements

/*
	
	beforebegin
	afterbegin

	beforeend
	afterend


*/

mydiv.insertAdjacentHTML('beforeend', `
	<div class="class-${classNumber}">
	<h1 style="background-color:rgb(${r}, ${g}, ${b});">Title</h1>
	<p>my paragraph</p>
	</div>
`)

// loops (for loops)
// forEach

	myParagraphs.forEach(function(paragraph, index){

		var shadowColor;

		if(index < 2){
			shadowColor = "black"
		}else{
			shadowColor = "red"
		}

		paragraph.style.textShadow = `2px ${index*2}px ${index}px ${shadowColor}`

	})


// for

var container = document.getElementById("container");

for (var i = 0; i < myArray.length; i++) {
	
	container.insertAdjacentHTML('beforeend', `
		<div id="module-${i}" class="module">${myArray[i]}</div>
		`)

}

// eventListeners
// click
// mousedown
// mouseenter
// mouseleave
// mousemove
// mouseover
// mouseout
// mouseup
// keydown
// keyup
// scroll 

var myButton = document.getElementById("myButton")

myButton.addEventListener('mousemove', function(event){

	console.log(event)

	event.target.style.left = event.pageX - 20 + "px"
	console.log(event.pageY + "px")


	if(event.shiftKey){
		console.log("shift was held down!")
		event.target.style.color = "red"
	}else{
		event.target.style.color = "blue"
	}

	container.style.backgroundColor = "lime"

})


var ourTyping = ""

window.addEventListener("keydown", function(event){
	// /event.preventDefault() // delay action
	ourTyping = ourTyping + event.key
	// console.log(ourTyping)
})


document.addEventListener("scroll", function(event){

	console.log(window.scrollY)

})











// asynchronous calls

