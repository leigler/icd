/* BOILERPLATE JS */

/* this is a comment */
console.log("hello!");