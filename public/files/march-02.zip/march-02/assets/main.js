/* variables 
	pieces of info to save for later!
*/

// string: (a piece of text)
var greeting = "hello!";

// you can redefine a variable like this:
greeting = "greetings!";

// numbers:
var integer = 2345;
var float = 3 * (-1.234 + integer);

// subtract 1
float--
float = float - 1;

// increase by 1
float++ 
float = float + 1;

// boolean
var myBoolean = true;
var myOtherBoolean = false;


// array (list)

var myArray = [
	"hello", 
	1.2, 
	"hello again", 
	["hello", "hi"]
];

// you can nest arrays inside each other
// to get specific value from an array, you call the array
// and pass the index (starting w 0 for the first element)
// console.log(myArray[0]) would output "hello"

// console.log(myArray[3][0])


// objects are collections
// each part of an object has a key and a value
var myObject = {
	key: "value",
	name: {
		firstname: "Lukas",
		last: "Eigler-Harding"
	},
	list : [1, "two", "three"]
};

// you can get the value of an object with its key in two ways
// pass the key as a string:
console.log(myObject['name']['firstname'])
// or use the key with dot notation:
console.log(myObject.name.firstname)



// a function is a set of commands or steps we save for later:
var myFunction = function(){

	console.log("hello!")

}


// you can pass arguments as placeholder variables through the ()
// returning a value means you can use the function to set a value
function adding(value, value2){
	return value + value2;
}

// example using the adding function:
var result = adding(10, 5)
var otherResult = adding(1100000, -5)

console.log(result)
console.log(otherResult)


// you can re-use a function as many times as you want:
myFunction()
myFunction()
myFunction()
myFunction()
myFunction()
myFunction()
myFunction()


/* conditionals
	
	if(){
	
	}else if(){
	
	}
*/

// === exactly equal to
// !== exactly not equal to
// == equal to, but can be different variables
// != not equal to

// < less than
// <= less than or equal to
// > greater than
// >= greater than or equal to


if(2020 <= 2010 || result === 15){
// run this
}else if(otherResult < 1000){
// run whatever is in here


}else{
// otherwise run this
}


// single element
// DOM
// Document Object Model
// console.log(document)
// to get a single element you can get it by its id:
var today = document.getElementById("today")

// or you can get the first matching element with querySelector
var myH1 = document.querySelector("h1")
var myH1 = document.querySelector("h1:last-of-type")


// you can define inline styles with .style.yourCssStyle
today.style.borderRadius = "20px"
myH1.style.borderRadius = "100px"


// you can add and remove classes as well:
// myH1.classList.remove("special")
// myH1.classList.add("special")
// myH1.classList.contains("special") returns true or false



// getting multiple elements returns a NodeList (similar to an array):
var myH1s = document.querySelectorAll("h1")


// cycling through our list of elements with forEach
myH1s.forEach(function(h1){
	h1.style.backgroundColor = "rgb(255,0,255)"
	h1.style.fontSize = "5rem"
	h1.style.color = "blue"
	h1.style.fontFamily = "Helvetica"
})

/* 
	intervals + settimeout (delays)
*/

// setTimeout takes two arguments:
// - a function
// - and a number (milliseconds)
setTimeout(function(){
	today.classList.add("special")

}, 2000)


var counter = 0;

/*

INTERLUDE: 

we can use the back ticks (``) to create multiline strings:

we can then place variables using the ${} syntax:

here are some different css styles in template literal form:

font size (or width/height):
	element.style.fontSize = `${variable}rem`;

color (or backgroundColor)
	element.style.color = `rgb(${red}, ${green}, ${blue})`

translateX
	element.style.transform = `translateX(${variable}px)`

box-shadow:
	element.style.boxShadow = `${left}px ${right}px ${blur} black`

*/


// intervals
var myInterval = setInterval(function(){

	counter = counter + 20;
	myH1s.forEach(function(h1){

		if(counter >= 3){
			// h1.style.fontSize = counter/2 + "rem";

			var red = counter;
			var blue = 255 - counter;

			h1.style.transform = "translateX(" + counter + "px)"

			h1.style.transform = `translateX(${counter}px)`
			h1.style.backgroundColor = `rgb(${red},0,${blue})`;

		}

		if(counter > 300){
			clearInterval(myInterval)
		}

	})
}, 1000)


/* UPDATING YOUR HTML CONTENT: */

// innerHTML
today.innerHTML = today.innerHTML + "testing testing" 

var container = document.getElementById("container")


/*

- beforebegin
- afterbegin
- beforeend
- afterend


*/

var title = "first"
var secondTitle = "second"



setInterval(function(){
	container.insertAdjacentHTML('beforeend', `

		<div style="font-size:${counter}px;">
			<h1>${title}</h1>
		</div>
	`)

}, 1000)


/* appending
	adding new html to our document
*/

// is a comment






